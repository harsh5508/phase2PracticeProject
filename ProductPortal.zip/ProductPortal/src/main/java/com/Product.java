package com;

public class Product 
{
	private int Pid;
	private String Pname;
	private int Pprice;
	private int Pqty;
	public int getPid() {
		return Pid;
	}
	public void setPid(int pid) {
			this.Pid = pid;
	}
	public String getPname() {
	    	return Pname;
	}
	public void setPname(String pname) {
			this.Pname = pname;
	}
	public int getPprice() {
			return Pprice;
	}
	public void setPrice(int pprice) {
			this.Pprice = pprice;
	}
    public int getPqty() {
			return Pqty;
	}
	public void setPqty(int pqty) {
		this.Pqty = pqty;
	}

}