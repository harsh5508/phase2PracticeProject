import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ProductServlet")
public class ProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String name = request.getParameter("prodname");
		int qty = Integer.parseInt(request.getParameter("prodqty"));
		float price = Float.parseFloat(request.getParameter("prodprice"));
		float total;
		PrintWriter out=response.getWriter();
		try {
			Connection con=DBConnection.getMyConnection();
			
			String str = "Insert into Product (pname,qty,price,total) values (?,?,?,?)";
			PreparedStatement  ps=con.prepareStatement(str);
			ps.setString(1, name);
			ps.setInt(2, qty);
			ps.setFloat(3, price);
			ps.setFloat(4, total = price*qty);
			
			int ans=ps.executeUpdate();
			if(ans>0)
				out.println("Record inserted");
			else
				out.println("Record not inserted");
			con.close();
			
		}
		catch(Exception e) {
			e.printStackTrace();
			
		}
	}


}
